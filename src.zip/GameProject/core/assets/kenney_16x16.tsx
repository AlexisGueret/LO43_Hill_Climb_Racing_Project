<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="kenney_16x16" tilewidth="16" tileheight="16" tilecount="6912" columns="64">
 <image source="../../../kenney_16x16.png" width="1024" height="1728"/>
</tileset>
