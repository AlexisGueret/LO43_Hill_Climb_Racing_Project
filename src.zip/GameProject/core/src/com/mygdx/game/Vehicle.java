package com.mygdx.game;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.joints.PrismaticJoint;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJoint;
import com.badlogic.gdx.physics.box2d.joints.WheelJoint;
import com.badlogic.gdx.physics.box2d.joints.WheelJointDef;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.mygdx.game.States.ChoiceState;
import com.mygdx.game.States.DeathState;
import com.mygdx.game.States.MainMenu;

public abstract class Vehicle extends InputAdapter {
	
protected float motorTorque=3001;
protected float deathY;
	
	protected World world;
	protected Body b2body;
	protected Image image; 
	protected int orientation=0;
	protected TextureRegion[] animation;
	protected Battery battery;
	protected Position pos;
	protected RevoluteJoint rearWheelRevoluteJoint;
	protected RevoluteJoint frontWheelRevoluteJoint;
	protected PrismaticJoint frontAxlePrismaticJoint;
	protected PrismaticJoint rearAxlePrismaticJoint;
	protected float motorspeed=75;
	protected Body chassis;
	  // private BodyDef chassisBodyDef;
	   protected FixtureDef chassisFixtureDef;
	  protected PolygonShape chassisShape;
	  // private Body rearWheel;
	 //  private BodyDef wheelBodyDef;
	   //private FixtureDef rearWheelFixtureDef;
	   //private Body frontWheel;
	   //private FixtureDef frontWheelFixtureDef;
	   protected boolean dead;
	   protected boolean isGrounded;
	 //  private WheelJoint rearAxis, frontAxis;
	   protected float x=6,y=2;
	   protected float height=0.1f,width=0.3f;
	   protected Body  leftWheel, rightWheel;
		protected WheelJoint leftAxis, rightAxis;
		protected Texture img;
	//	private OrthographicCamera gamecam;
		protected float timePassed=0;
		protected int numberOfContact=0;
		protected float rotation;
		protected PlayScreen ps;
	
	public Vehicle(World world, float e,PlayScreen ps)
	{
		
		this.deathY=e;
		
		this.world=world;
		this.ps=ps;

	}
	public boolean isDead()
	{
		return this.dead;
	}
	
	public void kill()
	{
		this.dead=true;
	}
	



	public void defineVehicle()
	{				
			BodyDef bodyDef = new BodyDef();
			bodyDef.type = BodyType.DynamicBody;
			bodyDef.position.set(ps.getGame().getMaps().get(ps.getMapNumber()).getxBegin(), ps.getGame().getMaps().get(ps.getMapNumber()).getyBegin());			
			// création du chassis
			PolygonShape chassisShape = new PolygonShape();
			chassisShape.set(new float[] {(-width/2 ) , (-height / 2), ( width / 2), (-height / 2), (width / 2 * .4f), (height / 2), (-width / 2 * .8f), (height / 2 * .8f)});
			chassisFixtureDef=new FixtureDef();
			chassisFixtureDef.shape = chassisShape;
			chassisFixtureDef.density=3f;
			chassisFixtureDef.friction=0.4f;
			chassisFixtureDef.restitution=0.3f;
			chassis = world.createBody(bodyDef);
			chassis.createFixture(chassisFixtureDef);

			// left wheel
			CircleShape wheelShape = new CircleShape();
			wheelShape.setRadius((height / 2.5f) );
			 FixtureDef wheelFixtureDef=new FixtureDef();
			wheelFixtureDef.shape = wheelShape;
			wheelFixtureDef.density = chassisFixtureDef.density*3.5f;
			wheelFixtureDef.friction=9f;
			wheelFixtureDef.restitution=0.3f;
			leftWheel = world.createBody(bodyDef);
			leftWheel.createFixture(wheelFixtureDef);
			// right wheel
			rightWheel = world.createBody(bodyDef);
			rightWheel.createFixture(wheelFixtureDef);
			// left axis( ce qui relie la roue gauche et le chassis)
			WheelJointDef axisDef = new WheelJointDef();
			axisDef.bodyA = chassis;
			axisDef.bodyB = leftWheel;
			axisDef.localAnchorA.set(-width / 2  + wheelShape.getRadius(), -height / 2 * 1.25f);
			axisDef.frequencyHz = chassisFixtureDef.density;			
			axisDef.localAxisA.set(Vector2.Y);
			axisDef.maxMotorTorque = motorTorque;
			leftAxis = (WheelJoint) world.createJoint(axisDef);

			// right axis ( ce qui relie la roue droite et le chassis)
			axisDef.bodyB = rightWheel;
			axisDef.localAnchorA.x *= -1;

			rightAxis = (WheelJoint) world.createJoint(axisDef);
			
			rightWheel.setUserData("car");
			leftWheel.setUserData("car");
			chassis.setUserData("car");
		}

	@Override
	public boolean keyDown(int keycode )
	{
		switch(keycode)
		{
		case Keys.Q : 
			if(!dead && this.battery.getBatteryLeft()>0)

			{
				this.getBattery().reduceBattery(1);
				leftAxis.enableMotor(true);
				if(!ps.getUser().getEngine().isEmpty()) {
					leftAxis.setMotorSpeed(ps.getUser().getEngine().get(0).getPower());
					rightAxis.enableMotor(true);
					rightAxis.setMotorSpeed(ps.getUser().getEngine().get(0).getPower());
				}
				else {
					leftAxis.setMotorSpeed(motorspeed);
					rightAxis.enableMotor(true);
					rightAxis.setMotorSpeed(motorspeed);
				}
			
			
			this.orientation=-1;
			}
			else if(this.battery.getBatteryLeft() < 1)
			{
				System.out.println("PERDU PLUS DE BATTERIE");
				this.kill();
				DeathState death = new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true);
				ps.getGame().setScreen(death);
				ps.getGame().getsm().set(new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true));
			}
			break;
			
		case Keys.D : 
			
			if(!dead && this.battery.getBatteryLeft()>0)
			{
				this.getBattery().reduceBattery(1);
				leftAxis.enableMotor(true);
				leftAxis.setMotorSpeed(-motorspeed);
				rightAxis.enableMotor(true);
				rightAxis.setMotorSpeed(-motorspeed);
				this.orientation=1;
			}
			else if(this.battery.getBatteryLeft() < 1)
			{
				System.out.println("PERDU PLUS DE BATTERIE");
				this.kill();
				DeathState death = new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true);
				ps.getGame().setScreen(death);
				ps.getGame().getsm().set(new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true));
			}
			break;
			
		case Keys.S : 
		}			
		return true;
	}
	
	
	
	@Override
	public boolean keyUp(int keycode )
	{
		switch(keycode)
		{
		case Keys.Q :	
		case Keys.D : 
			leftAxis.enableMotor(false);
			rightAxis.enableMotor(false);
			this.orientation=0;
			
		}
		return true;
	}

	public Body getBody()
	{
		return this.chassis;
	}
	
	public void addBattery(float value)
	{
		
	}
	
	
	public int getOrientation()
	{
		return this.orientation;
	}
	public Texture getImg() {
		return this.img;
	}
	
	
	public TextureRegion[] getArrayAnimation()
	{
		return animation;
	}
	
	public void setOrientation(int i)
	{
		this.orientation=i;
	}
	
	public Battery getBattery()
	{
		return this.battery;
	}
	
	
	public void update(float dt)
	{

		if(timePassed==60)
		{
			this.battery.reduceBattery(1);
			timePassed=0;
			
		}
		else
		{
			timePassed++;
		}
				
		rotation=(float)Math.toDegrees(this.getBody().getAngle());
		if(((rotation>175 || rotation<-175) && !this.isDead() && (this.getBody().getLinearVelocity().x<2) && isGrounded) || (this.getBody().getPosition().y<deathY && !this.isDead() ))
		{
			System.out.println("TU ES MORT ");
			this.kill();
			DeathState death = new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true);
			ps.getGame().setScreen(death);
			ps.getGame().getsm().set(new DeathState(ps.getGame().getsm(), ps.getGame().getUser(), ps.getGame(), ps, true));
				
		}
	
	}
	public boolean isGrounded() {
		return isGrounded;
	}
	public void setGrounded(boolean isGrounded) {
		this.isGrounded = isGrounded;
	}
	
	
	public Body getWheel()
	{
		return this.rightWheel;
	}
	public int getNumberOfContact() {
		return numberOfContact;
	}
	public void setNumberOfContact(int numberOfContact) {
		this.numberOfContact = numberOfContact;
	}

}
