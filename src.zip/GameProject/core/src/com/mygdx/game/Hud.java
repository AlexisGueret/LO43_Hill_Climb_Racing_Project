package com.mygdx.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class Hud {
	
	public Stage stage;
	private Viewport viewport;
	private Integer money;
	
	private int batteryleft;
	private User user;
	
	Label countdownLabel;
	Label bLabel;
	Label timeLabel;
	Label levelLabel;
	Label worldLabel;
	Label batteryLabel;
	PlayScreen ps;
	int mapnumber;
	
	
	public Hud(SpriteBatch sb,User user,PlayScreen ps)
	
	{
		this.ps=ps;
		this.user=user;
		money=user.getMoney();
		mapnumber=ps.getMapNumber();
		
		batteryleft=(int) ps.getCar().getBattery().getBatteryLeft();
		viewport=new FitViewport(CarGame.W_WIDTH,CarGame.W_HEIGHT,new OrthographicCamera());
		stage=new Stage(viewport,sb);
				
		
		Table table=new Table();
		table.top();
		table.setFillParent(true);
		
		countdownLabel = new Label(String.format("%03d", money), new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		bLabel = new Label(String.format("%06d", batteryleft), new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		timeLabel = new Label("MONEY", new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		levelLabel = new Label(String.valueOf(mapnumber), new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		worldLabel = new Label("LEVEL", new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		batteryLabel = new Label("BATTERY LEFT", new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		
		table.add(batteryLabel).expandX().padTop(10);
		table.add(worldLabel).expandX().padTop(10);
		table.add(timeLabel).expandX().padTop(10);
		table.row();
		table.add(bLabel).expandX();
		table.add(levelLabel).expandX();
		table.add(countdownLabel).expandX();
		stage.addActor(table);
	}
	
	
	public void Update()
	{
		money=user.getMoney();
		countdownLabel.setText(String.format("%03d", money));
		
		
		batteryleft=(int) ps.getCar().getBattery().getBatteryLeft();
		bLabel.setText(String.format("%03d", batteryleft));
		
	}
}
