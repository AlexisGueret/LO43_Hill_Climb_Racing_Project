package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;

public class Coin extends MapElement {	
	int i=0;
	boolean used=false;
	
	public Coin(int a,float x, float y, PlayScreen ps)
	{
		
		super(a,x,y,ps);
		pos.setX(x);
		pos.setY(y);		
		Texture text=new Texture("coin.png");		
		Sprite s = new Sprite(text);				
		s.setSize(s.getWidth()/(CarGame.PPM*7), s.getHeight()/(CarGame.PPM*7));
		setPosition(x,y);		
		this.set(s);
		this.setOrigin(this.getWidth()/2, this.getHeight()/2);
		ps.getCoinList().add(this);				
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = BodyType.DynamicBody;
		bodyDef.position.set(x+this.getWidth()/2,y);
		CircleShape cs=new CircleShape();
		cs.setRadius(this.getWidth()/2);
		FixtureDef csDef = new FixtureDef();
		csDef.density=0.1f;
		csDef.friction=2000000000;
		csDef.shape=cs;
		body=ps.getWorld().createBody(bodyDef);
		body.createFixture(csDef);
		body.setUserData("coin");				
	}
	
	
	public void draw(SpriteBatch sb)
	{
		super.draw(sb);						
	}
	
	
	
	
	public void Update(float dt)	
	{
		body.setAwake(false);
		
			if(body.getUserData().equals("destroyed"))
			{
				this.setPosition(pos.getX(), pos.getY()+200);
				use();
		
			}
			else
			{
				this.setPosition(pos.getX(), pos.getY());
			}
	
	}
	
	@Override
	public void use()
	{
		// ADD MONEY
		ps.getUser().addMoney(this.value);
	}
	
	public Body getBody()
	{
		return this.body;
	}

}
