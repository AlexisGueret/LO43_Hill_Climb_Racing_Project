package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.joints.PrismaticJoint;
import com.badlogic.gdx.physics.box2d.joints.PrismaticJointDef;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJoint;
import com.badlogic.gdx.physics.box2d.joints.RevoluteJointDef;
import com.badlogic.gdx.physics.box2d.joints.WheelJoint;
import com.badlogic.gdx.physics.box2d.joints.WheelJointDef;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class Car extends Vehicle
//extends Sprite
{
	
	
	private TextureRegion[] anima;
	Animation<TextureRegion> animation;

	public Car(World world,float e,PlayScreen p) {
		super(world,e,p);
		if(!p.getUser().getBatteries().isEmpty())
			this.battery = p.getUser().getBatteries().get(0);
		else
			this.battery=new Battery("default;40.001;10");
		super.defineVehicle();
		this.img=new Texture(Gdx.files.internal("1.png"));
		anima=new TextureRegion[4];
		anima[0]=new TextureRegion(new Texture("1.png"));
		anima[1]=new TextureRegion(new Texture("2.png"));
		anima[2]=new TextureRegion(new Texture("3.png"));
		anima[3]=new TextureRegion(new Texture("4.png"));
		
	}	
	
	
	public TextureRegion[] getArrayAnimation()
	{
		return this.anima;
	}
	
	public TextureRegion getTextureRegion()
	{
		return this.anima[0];
	}
	
	
	
	
	
	
	
}