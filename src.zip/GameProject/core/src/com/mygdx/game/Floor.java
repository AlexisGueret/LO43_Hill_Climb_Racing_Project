package com.mygdx.game;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.Shape;
import com.badlogic.gdx.physics.box2d.World;

public class Floor {

	public Floor(World world, TiledMap map)
	{
		BodyDef bdef=new BodyDef();
		//PolygonShape shape=new PolygonShape();
		FixtureDef fdef = new FixtureDef();
		Body body;
		for(MapObject object : map.getLayers().get(2).getObjects()){

            Shape shape;
           if (object instanceof RectangleMapObject) {
               shape = getRectangle((RectangleMapObject)object);
           }
           else if (object instanceof PolygonMapObject) {
               shape = getPolygon((PolygonMapObject)object);
           }
          
           else {
               continue;
           }
               bdef.type = BodyDef.BodyType.StaticBody;
               body = world.createBody(bdef);
               fdef.shape = shape;
               fdef.friction=0.09f;              
               body.createFixture(fdef);
               body.setUserData("floor");
               
           }
	}
	
	
	private static PolygonShape getRectangle(RectangleMapObject rectangleObject) {
        Rectangle rectangle = rectangleObject.getRectangle();
        PolygonShape polygon = new PolygonShape();
        Vector2 size = new Vector2((rectangle.x + rectangle.width * 0.5f)/CarGame.PPM ,
                                   (rectangle.y + rectangle.height * 0.5f )/CarGame.PPM );
        polygon.setAsBox((rectangle.width * 0.5f)/CarGame.PPM ,
                         (rectangle.height * 0.5f)/CarGame.PPM ,
                         size,
                         0.0f);
        return polygon;
    }

   

    private static PolygonShape getPolygon(PolygonMapObject polygonObject) {
        PolygonShape polygon = new PolygonShape();
        float[] vertices = polygonObject.getPolygon().getTransformedVertices();

        float[] worldVertices = new float[vertices.length];

        for (int i = 0; i < vertices.length; ++i) {
          
            worldVertices[i] = vertices[i]/CarGame.PPM;
        }

        polygon.set(worldVertices);
        return polygon;
    }
	
	

}
