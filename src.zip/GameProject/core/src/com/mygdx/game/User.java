package com.mygdx.game;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

import com.badlogic.gdx.Gdx;

public class User {
	private String username;
	private int goldAmount;	
	private ArrayList<Battery> userBatteries;
	private ArrayList<Engine> userEngines;
	
	public User() {
		this.username = new String("default");
		this.goldAmount = 0;
		
		this.userBatteries = new ArrayList<Battery>();
		this.userEngines = new ArrayList<Engine>();
	}
	
	public User(String name, int goldAmount) {
		this.username = new String(name);
		this.goldAmount = goldAmount;
		
		this.userBatteries = new ArrayList<Battery>();
		this.userEngines = new ArrayList<Engine>();
	}
	
	public User(String name, int goldAmount, ArrayList<Battery> bat, ArrayList<Engine> en) {
		this.username = new String(name);
		this.goldAmount = goldAmount;
		
		this.userBatteries = new ArrayList<Battery>(bat);
		this.userEngines = new ArrayList<Engine>(en);
	}
	
	public User(User u) {
		this.username = new String(u.username);
		this.goldAmount = u.goldAmount;
		
		this.userBatteries = new ArrayList<Battery>(u.userBatteries);
		this.userEngines = new ArrayList<Engine>(u.userEngines);
	}
	
	public void addMoney(int amount) {
		this.goldAmount += amount;
	}
	
	public void addBattery(Battery b) {
		this.userBatteries.add(b);
	}
	
	public void addEngine(Engine e) {
		this.userEngines.add(e);
	}
	
	public String toString() {
		String strBatteries = new String("Batteries:/");
		String strEngines = new String("Engines:/");
		
		for(Battery b : this.userBatteries) {
			strBatteries = strBatteries.concat(b.toString().concat("/"));
		}

		for(Engine e : this.userEngines) {
			strEngines = strEngines.concat(e.toString().concat("/"));
		}
		strEngines = strEngines.concat("-endEngines");
		
		return this.username + ";" + String.valueOf(this.goldAmount) + "endGold;" + strBatteries + strEngines;
	}
	
	public ArrayList<Engine> convertEngines(String engArray) {
		ArrayList<Engine> eng = new ArrayList<Engine>();
		int i = 1;
		ArrayList<Integer> count = new ArrayList<Integer>();
		count.add(0);
		char engines[] = engArray.toCharArray();
		while(i != engArray.length()) {
			if(engines[i] == '/'){
				count.add(i);
			}
			i++;
		}
		for(i = 0; i != count.size() -1 ; i++) {
			eng.add(new Engine(engArray.substring(count.get(i) + 1, count.get(i+1))));
		}
		return eng;
	}
	
	public ArrayList<Battery> convertBatteries(String batArray) {
		ArrayList<Battery> bat = new ArrayList<Battery>();
		int i = 1;
		ArrayList<Integer> count = new ArrayList<Integer>();
		count.add(0);
		char batteries[] = batArray.toCharArray();
		while(i != batArray.length()) {
			if(batteries[i] == '/'){
				count.add(i);
			}
			i++;
		}
		for(i = 0; i != count.size() -1 ; i++) {
			bat.add(new Battery(batArray.substring(count.get(i) + 1 , count.get(i+1))));
		}		
		return bat;
	}
	
	public User(String user) {
		int count = 0;
		username = user.substring(0, user.indexOf(";"));
		count += username.length() + 1;
		goldAmount = Integer.valueOf(user.substring(count, user.indexOf("endGold")));
		count += String.valueOf(goldAmount).length() + "endGold;".length();
		this.userBatteries = new ArrayList<Battery>(convertBatteries((user.substring(user.indexOf("Batteries:") + "Batteries:".length(), user.indexOf("Engines:")))));		
		this.userEngines = new ArrayList<Engine>(convertEngines((user.substring(user.indexOf("Engines:") + "Engines:".length(), user.indexOf("endEngines")))));
	}
	
	public String getUsername() {
		return this.username;
	}
	
	public int getMoney() {
		return this.goldAmount;
	}
	
	public ArrayList<Battery> getBatteries(){
		return this.userBatteries;
	}
	
	public ArrayList<Engine> getEngine(){
		return this.userEngines;
	}
	
	public void save() {
		try {
			File test = new File("TEST.txt");
			String path = new String(test.getAbsolutePath().toString().substring(0, test.getAbsolutePath().toString().indexOf("desk")) + "core/assets/");
			File users = new File(path + "users.txt");
			File tmp = new File(path + "tmp.txt");
			Scanner read = new Scanner(new FileInputStream(path + "users.txt"));
			FileWriter write = new FileWriter(tmp);
			String text;
			int lineNum = 0;
		    while (read.hasNextLine()) {
				text = new String(read.nextLine());
				if(!text.substring(0, text.indexOf(";")).equals(this.username)) {
					write.write(text + "\n");
				}
			}
			read.close();
			write.write(this.toString());
		    write.close();
		    users.delete();
		    tmp.renameTo(users);
		}catch(Exception e) {
			System.out.println("File not loaded");
		}
	}
}

