package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class Engine extends CarComponent {

	private float power;
	private int type;
	private Texture engineTexture;
	private Image logo;
	private int price;
	
	public Engine(Engine e) {
		super(e.getName());
		this.power = e.getPower();
		this.type = e.getType();
		this.price = e.getPrice();
		this.engineTexture = e.getEngineTexture();
		this.logo = new Image(engineTexture);
	}
	
	public Texture getEngineTexture() {
		return this.engineTexture;
	}
	
	public boolean equals(Engine e) {
		return this.power == e.getPower() && this.price == e.getPrice() && this.type == e.getType() && this.name.equals(e.getName());
	}
	
	public Engine(String n, float power, int type, int price)
	{
		super(n);
		this.price = price;
		this.engineTexture= new Texture(Gdx.files.internal("engine.PNG"));
		this.logo = new Image(engineTexture);
		this.power=power;
		this.type=type;
	}	
	public float getPower()
	{
		return this.power;
	}
	
	public int getType() {
		return this.type;
	}
	
	public String toString() {
		return this.name + ";" + String.valueOf(this.power) + ";" + String.valueOf(this.type) + ":" + String.valueOf(this.price);
	}
	
	public Image getLogo() {
		return this.logo;
	}
	
	public Engine(String engine) {
		super(engine.substring(0, engine.indexOf(";")));
		int count = 0;
		count += name.length() + 1;
		this.power = Float.valueOf(engine.substring(count, engine.lastIndexOf(";")));
		count += engine.substring(count, engine.lastIndexOf(";")).length() + 1;
		type = Integer.valueOf(engine.substring(count, engine.indexOf(":")));
		count += String.valueOf(type).length() + 1;
		this.price = Integer.valueOf(engine.substring(count, engine.length()));
		this.engineTexture= new Texture(Gdx.files.internal("engine.PNG"));
		this.logo = new Image(engineTexture);
	}
	
	public int getPrice() {
		return this.price;
	}
	
	public String getName() {
		return this.name;
	}
}
