package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;

public class FuelCell extends MapElement {

	public FuelCell(int i, float x, float y, PlayScreen ps) 
	{
		super(i, x, y, ps);		
		Texture text=new Texture("duracell2.png");
		
		Sprite s = new Sprite(text);				
		s.setSize(s.getWidth()/(17*CarGame.PPM), s.getHeight()/(17*CarGame.PPM));
		setPosition(x,y);		
		this.set(s);
		this.setOrigin(this.getWidth()/2, this.getHeight()/2);
		ps.getCoinList().add(this);				
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = BodyType.StaticBody;
		bodyDef.position.set(x+this.getWidth()/2,y);
		CircleShape cs=new CircleShape();
		cs.setRadius(this.getWidth()/2);
		FixtureDef csDef = new FixtureDef();
		csDef.density=0.1f;
		csDef.shape=cs;
		body=ps.getWorld().createBody(bodyDef);
		body.createFixture(csDef);
		body.setUserData("coin");
	}
	
public void Update(float dt)
	
	{
		
			if(body.getUserData().equals("destroyed"))
			{
				this.setPosition(pos.getX(), pos.getY()+200);
				use();	
			}
			else
			{
				this.setPosition(pos.getX(), pos.getY());
			}
	}

	@Override
	public void use()
	{
		// ADD Battery
		ps.getCar().getBattery().addBattery(10);
	}
	
	public Body getBody()
	{
		return this.body;
	}
}