package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.Body;

public abstract class MapElement extends Sprite {
	
	protected int value;
	protected Position pos;
	protected PlayScreen ps;
	protected Body body;
	public MapElement(int i, float x, float y, PlayScreen ps)
	{
		this.value=i;
		pos=new Position(x,y);
		this.ps=ps;
	}
	
	
	public void Update(float dt)
	{
		
	}
	
	public void use()
	{
		
	}
	
	public Body getBody()
	{
		return this.body;
	}
	
	public void dispose()
	{
		this.getBody().setUserData("destroyed");
	}
	

}
