package com.mygdx.game;

public abstract class CarComponent {
	
	protected String name;
	
	public CarComponent(String name) {
		this.name = new String(name);
	}
}
