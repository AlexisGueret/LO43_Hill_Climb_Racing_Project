package com.mygdx.game;

import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class Battery extends CarComponent{
	
	private Image[] levelOfCarburant;
	private String logoPath;
	private Texture batteryTexture;
	private Image logo;
	private float batteryLeft;
	private int price;
	
	public Battery(Battery b) {
		super(b.getName());
		this.batteryTexture = b.getTexture();
		this.logo = new Image(batteryTexture);
		this.price = b.getPrice();
		this.levelOfCarburant = b.getLevelOfCarburant();
		this.batteryLeft = b.getBatteryLeft();
	}
	
	public Texture getTexture() {
		return this.batteryTexture;
	}
	
	public Image[] getLevelOfCarburant() {
		return this.levelOfCarburant;
	}
	
	public String getLogoPath() {
		return this.logoPath;
	}
	
	public String toString() {
		return this.name + ";" + String.valueOf(this.batteryLeft + ";" + String.valueOf(this.price));
	}
	
	public boolean equals(Battery b) {
		return this.name.equals(b.getName()) && this.batteryLeft == b.getBatteryLeft() && this.price == b.getPrice();
	}
	
	public Battery(String strBattery) {
		super(strBattery.substring(0, strBattery.indexOf(";")));
		int count = 0;
		count += name.length() + 1;
		batteryLeft = Float.valueOf(strBattery.substring(count, strBattery.lastIndexOf(";")));
		count += String.valueOf(batteryLeft).length() + 1;
		price = Integer.valueOf(strBattery.substring(count, strBattery.length()));
		this.batteryTexture = new Texture(Gdx.files.internal("battery.PNG"));
		this.logo = new Image(batteryTexture);
	}
	
	public Battery(String n, float amount, int price)
	{
		super(n);
		this.price = price;
		this.batteryLeft = amount;
		this.batteryTexture = new Texture(Gdx.files.internal("battery.PNG"));
		this.logo = new Image(batteryTexture);
	}
	
	public boolean updateBattery(Engine e)
	{
		if(this.batteryLeft > 0) {
			this.batteryLeft -= (e.getPower()/12);
			return true;
		}
		else {
			return false;
		}
	}
	
	public void reduceBattery(float f) {
		if(this.batteryLeft > 0)
			this.batteryLeft -= f;
	}
	
	public void addBattery(float amount) {
		this.batteryLeft += amount;
	}
	
	public String getName() {
		return this.name;
	}
	
	public float getBatteryLeft() {
		return this.batteryLeft;
	}
	
	public Image getLogo() {
		return this.logo;
	}
	
	public int getPrice() {
		return this.price;
	}

}
