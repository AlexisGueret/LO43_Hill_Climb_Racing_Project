package com.mygdx.game;

import java.util.ArrayList;
import java.util.Iterator;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.objects.CircleMapObject;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.PolylineMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.objects.TextureMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Polygon;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.ChainShape;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.Shape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.States.DeathState;
import com.mygdx.game.States.MainMenu;

public class PlayScreen implements Screen {
	private CarGame game;
	
	private OrthographicCamera gamecam;
	private Viewport gamePort;
	private Hud hud;	
	private TmxMapLoader mapLoader;
	private TiledMap map;		
	private OrthogonalTiledMapRenderer renderer;	
	private World world;
	private Box2DDebugRenderer b2dr;
	private	Car car;
	private CarView cv;	
	private ArrayList<MapElement> mapElementList;
	private ArrayList<Body> destroyArray;
	private User user;
	private int currentmap;
	public PlayScreen(final CarGame game,final int currentmape)
	{
		user=new User(game.getUser());
		this.currentmap=currentmape;
		this.game=game;
		destroyArray=new ArrayList<Body>();
		gamecam=new OrthographicCamera();
		gamePort=new FitViewport(CarGame.W_WIDTH/CarGame.PPM,CarGame.W_HEIGHT/CarGame.PPM,gamecam);
		mapLoader = new TmxMapLoader();		
		map=mapLoader.load(game.getMaps().get(currentmap).getPath());
		renderer = new OrthogonalTiledMapRenderer(map,1/CarGame.PPM);		
		gamecam.position.set(gamePort.getWorldWidth()/2,gamePort.getWorldHeight()/2,0);		
		//the boolean is for gravity : true = no gravity
		world=new World(new Vector2(0,-6f),true);
		b2dr=new Box2DDebugRenderer();
		Floor f = new Floor(world, map);          
        car=new Car(this.world,game.getMaps().get(currentmap).getDeath(),this);
        hud=new Hud(game.getSpriteBatch(),user,this);       
        Gdx.input.setInputProcessor(new InputMultiplexer(new InputAdapter() {

			@Override
			public boolean keyDown(int keycode) {
				switch(keycode) {
				case Keys.A : 
						restart();
					
					
				
					break;
				}
				return false;
			}

			@Override
			public boolean scrolled(int amount) {
				gamecam.zoom += amount / 50f;
				return true;
			}

		}, car));
       
            
       
	mapElementList=game.getMaps().get(currentmap).getElements();
	cv=new CarView(car,this);
	game.getMaps().get(currentmap).createElements(this);
	
	world.setContactListener(new ContactListener() {

		@Override
		public void beginContact(Contact contact) {
			// TODO Auto-generated method stub
			if((contact.getFixtureA().getBody().getUserData().equals("coin") && contact.getFixtureB().getBody().getUserData().equals("car")) )
			{				
				if(!AlreadyinDestroyArray(contact.getFixtureA().getBody()))
				{
					destroyArray.add(contact.getFixtureA().getBody());					
				}				
			}						
			if(contact.getFixtureB().getBody().getUserData().equals("coin") && contact.getFixtureA().getBody().getUserData().equals("car"))
					{
				if(!AlreadyinDestroyArray(contact.getFixtureB().getBody()))
				{			
					destroyArray.add(contact.getFixtureB().getBody());			
				}						
					}
			
			
			if(contact.getFixtureA().getBody().getUserData().equals("floor") && contact.getFixtureB().getBody().getUserData().equals("car"))
			{
				car.setGrounded(true);
				car.setNumberOfContact(car.getNumberOfContact()+1);
			}
			
			
			if(contact.getFixtureB().getBody().getUserData().equals("floor") && contact.getFixtureA().getBody().getUserData().equals("car"))
			{
				car.setGrounded(true);
				car.setNumberOfContact(car.getNumberOfContact()+1);
			}
		}
		@Override
		public void endContact(Contact contact) {
			// TODO Auto-generated method stub
			if(contact.getFixtureA().getBody().getUserData().equals("floor") && contact.getFixtureB().getBody().getUserData().equals("car"))
			{
				car.setNumberOfContact(car.getNumberOfContact()-1);
				if(car.getNumberOfContact()==0)
				{
					car.setGrounded(false);
				}				
			}			
			
			if(contact.getFixtureB().getBody().getUserData().equals("floor") && contact.getFixtureA().getBody().getUserData().equals("car"))
			{
				car.setNumberOfContact(car.getNumberOfContact()-1);
				if(car.getNumberOfContact()==0)
				{
					car.setGrounded(false);
				}
			}						
		}
		@Override
		public void preSolve(Contact contact, Manifold oldManifold) {
			// TODO Auto-generated method stub			
		}

		@Override
		public void postSolve(Contact contact, ContactImpulse impulse) {
			// TODO Auto-generated method stub
			
		}      
});
	
	}	
	public Vehicle getCar()
	{
		return this.car;
	}
        
        
		
		
		
		
		
		
		
	

	
	public void update(float dt)
	{
		handleInput(dt);		
		world.step(1/60f, 6, 2);
		for(Body b : destroyArray)
		{
			if(!b.getUserData().equals("destroyed"))
			{
				if(!world.isLocked())
				{
				world.destroyBody(b);
				b.setUserData("destroyed");
				}
			}			
		}
		car.update(dt);
		hud.Update();
		cv.update(dt);
		for(MapElement c : mapElementList)
		{
			c.Update(dt);
		}
		HandleCam();
		gamecam.update();
		renderer.setView(gamecam);
		if(car.getBody().getPosition().x>game.getMaps().get(currentmap).getEnd())
		{
			System.out.println("BIEN JOUE TU AS FINIS LA COURSE");
			user.save();
			this.getGame().setScreen(new MainMenu(this.getGame().getsm(), user, this.getGame(), true, this));
		}		
	}
	
	public void HandleCam()
	{
		if(!car.isDead())
		{
		gamecam.position.x=car.getBody().getPosition().x;
		}		
	}

	public void handleInput(float dt)
	{
		if(Gdx.input.isTouched())
		{
			gamecam.position.x+=100*dt/CarGame.PPM;
		}
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		update(delta);
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		//Affiche la map		
		renderer.render();
	
		//Affiche les lignes de box2d
		//	b2dr.render(world, gamecam.combined);
		
		game.getSpriteBatch().setProjectionMatrix(gamecam.combined);
		
		game.getSpriteBatch().begin();
		
			
		for(Iterator<MapElement> it= mapElementList.iterator();it.hasNext();)				
		{
				MapElement c=it.next();
				c.draw(game.getSpriteBatch());
				if(c.getBody().getUserData().equals("destroyed"))
				{
					it.remove();
				}			
		}				
		cv.draw(game.getSpriteBatch());		
		game.getSpriteBatch().end();		
		game.getSpriteBatch().setProjectionMatrix(hud.stage.getCamera().combined);
		hud.stage.draw();	
	}

	@Override
	public void resize(int width, int height) {
		gamePort.update(width, height);		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
		
		map.dispose();
        renderer.dispose();
        world.dispose();
        b2dr.dispose();
        for(MapElement e : this.mapElementList)
        {
        	e.dispose();
        }
       
	}	
	public ArrayList<MapElement> getCoinList()
	{
		return this.mapElementList;
	}
	
	public CarView getCarView()
	{
		return this.cv;
	}

	public World getWorld()
	{
		return this.world;
	}
	
	
	public boolean AlreadyinDestroyArray(Body b)
	{
		for(Body bo : destroyArray)
		{
			if(bo==b)
			{
				return  true;
			}
			
		}
		return false;
	}
    public User getUser()
    {
    	return this.user;
    }
    
    public void restart()
    {
    	dispose();
		game.setScreen(new PlayScreen(game,currentmap));
    }
    
    public int getMapNumber()
    {
    	return this.currentmap;
    }
    
    public CarGame getGame()
    {
    	return this.game;
    }
    
}
