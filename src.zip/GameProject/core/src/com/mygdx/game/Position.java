package com.mygdx.game;

public class Position {
	
	private float x;
	private float y;
	
	
	public Position(float a,float b)
	{
		this.x=a;
		this.y=b;
	}
	
	public void setX(float a)
	{
		this.x=a;	
	}
	public void setY(float a)
	{
		this.y=a;
	}
	public float getX()
	{
		return this.x;
	}
	public float getY()
	{
		return this.y;
	}

}
