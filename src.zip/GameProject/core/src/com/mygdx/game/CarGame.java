/*
package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class CarGame extends Game {
	public SpriteBatch batch;
	
	
	
	
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		setScreen(new PlayScreen(this));
		
	}

	@Override
	public void render () {
		super.render();
		
		
	}
	
	
}*/
package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

import java.io.File;
import java.util.ArrayList;
import com.mygdx.game.States.*;
import com.badlogic.gdx.scenes.scene2d.InputListener;

public class CarGame extends Game {
	public static final float PPM=100;
//	public static final int WIDTH = 600;
	//public static final int HEIGHT = 480;
	public static final String TITLE = "ECO RALLYE";
	public static final int W_WIDTH=400;
	public static final int W_HEIGHT=208;
	private MainMenu main;
	private Stage stage;
	private StateManager sm;
	private SpriteBatch batch;
	private Map map1;
	private Map map2;
	private ArrayList<Map> maps;
	private User u;
	public PlayScreen ps;
	public void create() {

		map2=new Map("DesertTileMap.tmx",1,38f,-1f,1f,3);
		map1=new Map("TileMapLO43.tmx",0,36.74f,-1f,1,2);
		maps=new ArrayList<Map>();
		maps.add(map1);
		maps.add(map2);
		//File test = new File("TEST.txt");
		//String path = new String(test.getAbsolutePath().toString().substring(0, test.getAbsolutePath().toString().indexOf("desk")) + "core/assets/");

		//Battery defautBat = new Battery("default", (float)50.0, 0);
		//Engine defautEn = new Engine("default", (float)75, 0, 0);
		
		u = new User("default", 1000);
		/*u.getBatteries().add(defautBat);
		u.getEngine().add(defautEn);*/
		batch=new SpriteBatch();
		stage = new Stage(new ScreenViewport());
		sm = new StateManager();
		sm.push(new MainMenu(sm,u,this, false, ps));
		//setScreen(new PlayScreen(this));
		
	}
	
	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		sm.render(stage);
		super.render();
		//super.render();
		
	}
	
	
	public SpriteBatch getSpriteBatch()
	{
		return this.batch;
	}
	
	public ArrayList<Map> getMaps()
	{
		return this.maps;
	}
	public StateManager getsm()
	{
		return this.sm;
	}
	
	public User getUser()
	{
		return this.u;
	}
}

