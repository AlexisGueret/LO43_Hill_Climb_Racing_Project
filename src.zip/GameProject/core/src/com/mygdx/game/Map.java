package com.mygdx.game;

import java.util.ArrayList;

public class Map {
	
	
	private String path;
	private ArrayList<MapElement> mapElementList;
	private int mapNumber;
	private float endX;
	private float deathY;
	private float xBegin;
	private float yBegin;
	
	public Map(String s,int i,float end,float death,float x,float y)
	{
		mapElementList=new ArrayList<MapElement>();
		this.path=s;
		this.mapNumber=i;
		this.endX=end;
		this.deathY=death;
		this.xBegin=x;
		this.yBegin=y;		
	}
	
	public String getPath()
	{
		return this.path;
	}
		
	public ArrayList<MapElement> getElements()
	{
		return this.mapElementList;
	}
	
	public void createElements(PlayScreen ps)
	{
		
		if(this.mapNumber==0)
		{					
		new FuelCell(10,7.5f,0.32f,ps);		
		new Coin(5,1.75f,0.33f,ps);
		new Coin(10,1.97f,0.52f,ps);
		new Coin(10,2.5f,0.65f,ps);
		new Coin(10,2.75f,0.65f,ps);
		new Coin(10,3f,0.66f,ps);
		new Coin(10,4.03f,0.96f,ps);		
		new Coin(10,6,0.32f, ps);
		new Coin(10,7,0.32f, ps);
		new Coin(10,8.5f,0.32f, ps);
		new Coin(10,10.5f,0.32f, ps);
		new Coin(10,12.5f,0.32f, ps);
		new FuelCell(10,12f,0.32f, ps);
		new Coin(10,14.5f,0.65f, ps);				
		new Coin(10,15.5f,1.25f, ps);
		new Coin(10,17.5f,0.4f, ps);
		new Coin(10,19.5f,0.95f, ps);
		new Coin(10,24f,0.5f, ps);
		new Coin(10,24.5f,0.5f, ps);
		new Coin(10,25f,0.5f, ps);
		new Coin(10,31f,0.35f, ps);
		new Coin(10,31.5f,0.35f, ps);
		new Coin(10,32f,0.35f, ps);
		new Coin(10,32.5f,0.35f, ps);
		new Coin(10,33f,0.35f, ps);
		new Coin(10,33.5f,0.35f, ps);
		new Coin(10,34f,0.35f, ps);
		new Coin(10,34.5f,0.35f, ps);
		new Coin(10,35f,0.35f, ps);
		new Coin(10,35.5f,0.35f, ps);
		new Coin(10,36f,0.35f, ps);
		new Coin(500,36.5f,0.35f, ps);
		}
		else
		{
			new Coin(5,2f,1.45f,ps);
			new Coin(5,2.5f,1.45f,ps);
			new Coin(5,3f,1.45f,ps);	
			new Coin(5,3.75f,1.65f,ps);
			new Coin(5,4.2f,1.45f,ps);
			new Coin(5,6f,1.65f,ps);
			new Coin(5,8f,1.45f,ps);
			new Coin(5,8.8f,1.45f,ps);
			new Coin(5,10f,0.5f,ps);
			new Coin(5,10.5f,0.5f,ps);
			new Coin(5,11f,0.5f,ps);
			new Coin(5,11.5f,0.5f,ps);
			new Coin(5,12f,0.5f,ps);
			new Coin(5,13f,0.5f,ps);
			new Coin(5,14f,0.5f,ps);
			new Coin(5,15f,0.5f,ps);			
			new Coin(5,15.5f,0.5f,ps);
			new Coin(5,16f,0.5f,ps);
			new FuelCell(5,16.5f,0.5f,ps);			
			new Coin(5,17f,0.5f,ps);
			new Coin(5,18f,0.5f,ps);
			new Coin(5,19.5f,0.5f,ps);
			new Coin(5,21.5f,0.7f,ps);
			new Coin(5,22.5f,0.7f,ps);
			new Coin(5,24f,0.73f,ps);
			new Coin(5,24.7f,1.17f,ps);
			new Coin(5,25.2f,1.17f,ps);
			new Coin(5,28.5f,1.8f,ps);
			new FuelCell(5,29f,1.77f,ps);
			new Coin(5,29.5f,1.8f,ps);
			new Coin(5,31f,2.3f,ps);
			new Coin(5,32f,1.83f,ps);
			new Coin(5,33.5f,1.5f,ps);
			new Coin(5,35,1.15f,ps);
			new Coin(500,38f,0.25f,ps);
		}
	}
	
	
	public float getEnd()
	{
		return this.endX;
	}
	
	
	public float getDeath()
	{
		return this.deathY;
	}

	public float getxBegin() {
		return xBegin;
	}

	public float getyBegin() {
		return yBegin;
	}

}
