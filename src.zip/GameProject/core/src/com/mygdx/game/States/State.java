package com.mygdx.game.States;

public abstract class State{
	protected final StateManager sm;
	
	public State(StateManager sm){
		this.sm = sm;
    }

	public abstract void render();
}
