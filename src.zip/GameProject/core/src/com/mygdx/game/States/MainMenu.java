package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.mygdx.game.CarGame;
import com.mygdx.game.PlayScreen;
import com.mygdx.game.User;

public class MainMenu extends State implements Screen{
	public int WIDTH = 600;
	public int HEIGHT = 480;
	private Stage stage;
	private TextButton game, shop, users, equip, exit;
	private Skin skin;
	private User user;
	private Label userlabel;
	
		public MainMenu(final StateManager sm, User u, final CarGame cargame, final  boolean restart, final PlayScreen pscr) {
		super(sm);
		
		// INITIALISATION
		skin = new Skin(Gdx.files.internal("glassy/glassy-ui.json"));
		stage = new Stage(new ScreenViewport());	
		Gdx.input.setInputProcessor(stage);
		this.user = u;
		userlabel = new Label(u.getUsername() + "\n" + String.valueOf(u.getMoney()) + " pO", skin);
		userlabel.setPosition(WIDTH - userlabel.getWidth(), HEIGHT - userlabel.getHeight());
		stage.addActor(userlabel);

		
		// CREATION
		game = new TextButton("Jouer", skin, "small");
		shop = new TextButton("Magasin", skin, "small");
		users = new TextButton("Charger / Creer un compte", skin, "small");
		equip = new TextButton("Equipement", skin, "small");
		exit = new TextButton("Quitter", skin, "small");
		
		// LISTENER
		game.addListener(new MyInputListener(this.user, restart, pscr) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new ChoiceState(sm, user, cargame, restart, pscr));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		shop.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new ShopState(sm, user, cargame, restart, pscr));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		users.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new UserState(sm, user, cargame, restart, pscr));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
            	return true;
            }
		});
		equip.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new EquipmentState(sm, user, cargame, restart, pscr));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		exit.addListener(new InputListener() {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				Gdx.app.exit();
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
				
		// PLACEMENT
		game.setPosition(WIDTH/2 - game.getWidth()/2, HEIGHT - (float)1.5 * game.getHeight());
		shop.setPosition(WIDTH/2 - shop.getWidth()/2, HEIGHT - (float)3 * shop.getHeight());
		users.setPosition(WIDTH/2 - users.getWidth()/2,  HEIGHT - (float)4.5 * users.getHeight());
		equip.setPosition(WIDTH/2 - equip.getWidth()/2,  HEIGHT - (float)6 * equip.getHeight());
		exit.setPosition(WIDTH - exit.getWidth(), 20);
			
		stage.addActor(game);
		stage.addActor(shop);
		stage.addActor(users);
		stage.addActor(exit);
		stage.addActor(equip);
	}
    

	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
