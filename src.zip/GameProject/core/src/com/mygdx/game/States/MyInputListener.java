package com.mygdx.game.States;

import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.mygdx.game.*;

public class MyInputListener extends InputListener {
		
	public MyInputListener(User u) {
		super();
	}
	public MyInputListener(User u, boolean restart, PlayScreen ps) {
		super();
	}
	public MyInputListener(User u, Engine e) {
		super();
	}
	public MyInputListener(User u, Battery b) {
		super();
	}
	public MyInputListener(User u, Engine e, int i) {
		super();
	}
	public MyInputListener(User u, Battery b, int i) {
		super();
	}
}
