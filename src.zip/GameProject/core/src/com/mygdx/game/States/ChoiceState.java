package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.mygdx.game.*;

public class ChoiceState extends State implements Screen {
	
	public static final int WIDTH = 600;
	public static final int HEIGHT = 480;
	private Stage stage;
	private Skin mySkin;
	private TextButton backToMenu, lvl1, lvl2;
	private Label userlabel;
	private User user;
	
	public ChoiceState(final StateManager sm, User u, final CarGame cargame, final boolean restart, final PlayScreen pscr) {
		super(sm);
		stage = new Stage(new ScreenViewport());
		mySkin = new Skin(Gdx.files.internal("glassy/glassy-ui.json"));
		this.user = u;
		Gdx.input.setInputProcessor(stage);
		userlabel = new Label(user.getUsername() + "\n" + String.valueOf(user.getMoney()) + " pO", mySkin);
		userlabel.setPosition(WIDTH - userlabel.getWidth(), HEIGHT - userlabel.getHeight());
		stage.addActor(userlabel);
		
		this.backToMenu = new TextButton("Retour", mySkin, "small");
		this.backToMenu.setPosition(WIDTH - backToMenu.getWidth() , backToMenu.getHeight());
		backToMenu.addListener(new MyInputListener(this.user) {
			@Override
	        public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new MainMenu(sm, user, cargame, restart, pscr));	
	        }
	        @Override
	        public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
	        	return true;
	        }
		}
		);
		stage.addActor(backToMenu);
		
		
		this.lvl1 = new TextButton("Niveau 1", mySkin, "small");
		this.lvl1.setPosition(WIDTH/2 - lvl1.getWidth()/2 -100 , HEIGHT/2 - lvl1.getHeight()/2);
		lvl1.addListener(new MyInputListener(this.user, restart, pscr) {
			@Override
	        public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				if(!restart)
					cargame.setScreen(new PlayScreen(cargame, 0));
				else {
					pscr.restart();
				}
					
	        }
	        @Override
	        public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
	        	return true;
	        }
		}
		);
		stage.addActor(lvl1);
		this.lvl2 = new TextButton("Niveau 2", mySkin, "small");
		this.lvl2.setPosition(WIDTH/2 - lvl2.getWidth()/2 + 100 , HEIGHT/2 - lvl2.getHeight()/2);
		lvl2.addListener(new MyInputListener(this.user, restart, pscr) {
			@Override
	        public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				if(!restart)
					cargame.setScreen(new PlayScreen(cargame, 1));
				else
					pscr.restart();
			}
	        @Override
	        public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
	        	return true;
	        }
		}
		);
		stage.addActor(lvl2);
	}
	
	@Override
	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
}

