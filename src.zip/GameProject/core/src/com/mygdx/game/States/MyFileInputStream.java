package com.mygdx.game.States;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import com.badlogic.gdx.files.FileHandle;

public class MyFileInputStream extends FileInputStream {
	public MyFileInputStream(File file, FileHandle handle) throws FileNotFoundException {
		super(file);
	}
}
