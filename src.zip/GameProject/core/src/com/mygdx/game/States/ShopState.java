package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.Align;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

import com.mygdx.game.*;

public class ShopState extends State {

	public static final int WIDTH = 600;
	public static final int HEIGHT = 480;
	private ArrayList<Engine> engines;
	private ArrayList<Battery> batteries;
	private Stage stage;
	private Skin mySkin;
	private ArrayList<TextButton> buttons;
	private TextButton backToMenu;
	private ArrayList<Label> labels;
	private Label userlabel;
	private User user;
	private JOptionPane input;
	private boolean exists;
		
	public ShopState(final StateManager sm, User u, final CarGame cargame, final boolean restart, final PlayScreen pscr) {
		super(sm);
		
		// INITIALISATION
		int i,j;
		float gW, gH, eH, bH, eW, bW, space;
		stage = new Stage(new ScreenViewport());
		mySkin = new Skin(Gdx.files.internal("glassy/glassy-ui.json"));
		this.user = u;
		Gdx.input.setInputProcessor(stage);
		userlabel = new Label(user.getUsername() + "\n" + String.valueOf(user.getMoney()) + " pO", mySkin);
		userlabel.setPosition(WIDTH - userlabel.getWidth(), HEIGHT - userlabel.getHeight());
		stage.addActor(userlabel);
		

        // Cr�ation
		this.backToMenu = new TextButton("Retour", mySkin, "small");		
		this.backToMenu.setPosition(WIDTH - backToMenu.getWidth() , backToMenu.getHeight());
		backToMenu.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new MainMenu(sm, user, cargame, false, pscr));
				
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		}
		);
		stage.addActor(backToMenu);
		buttons = new ArrayList<TextButton>();
		labels = new ArrayList<Label>();
		try {
			//File testp = new File("TEST.txt");
			//String path = new String(testp.getAbsolutePath().toString().substring(0, testp.getAbsolutePath().toString().indexOf("desk")) + "core/assets/");
			Scanner readEn = new Scanner(Gdx.files.internal("engines_shop.txt").read());
			Scanner readBat = new Scanner(Gdx.files.internal("batteries_shop.txt").read());
			engines = new ArrayList<Engine>();
			batteries = new ArrayList<Battery>();
			if(user.getBatteries().size() == 0 && user.getEngine().size() == 0) {				
				while(readBat.hasNextLine() && readEn.hasNextLine()) {
					String lineBat = new String(readBat.nextLine());
					String lineEn = new String(readEn.nextLine());
					
					engines.add(new Engine(lineEn));
					batteries.add(new Battery(lineBat));
				}
				readEn.close();
				readBat.close();
			}
			else if(user.getEngine().size() == 0 && user.getBatteries().size() > 0) {
				engines = new ArrayList<Engine>();
				batteries = new ArrayList<Battery>();
				
				while(readEn.hasNextLine()) {
					String lineEn = new String(readEn.nextLine());
					engines.add(new Engine(lineEn));
				}
				while(readBat.hasNextLine()) {
					exists = false;
					String line = new String(readBat.nextLine());
					Battery tmp = new Battery(line);
					for(i = 0; i != user.getBatteries().size(); i++) {
						if(user.getBatteries().get(i).equals(tmp)) {
							exists = true;
						}
					}
					if(!exists)
						batteries.add(new Battery(tmp));
				}
				readEn.close();
				readBat.close();
			}
			else if(user.getEngine().size() > 0 && user.getBatteries().size() == 0) {
				engines = new ArrayList<Engine>();
				batteries = new ArrayList<Battery>();
				
				while(readBat.hasNextLine()) {
					String lineBat = new String(readBat.nextLine());
					batteries.add(new Battery(lineBat));
				}
				while(readEn.hasNextLine()) {
					exists = false;
					String line = new String(readEn.nextLine());
					Engine tmp = new Engine(line);
					
					for(i = 0; i != user.getEngine().size(); i++) {
						if(user.getEngine().get(i).equals(tmp)) {
							exists = true;
						}
					}
					if(!exists)
						engines.add(new Engine(tmp));
				}
				readEn.close();
				readBat.close();
			}
			else if(user.getEngine().size() == 3 && user.getBatteries().size() == 3) {
				JOptionPane.showMessageDialog(null, "Plus d'ameliorations, retour au menu principal", "Penurie", input.INFORMATION_MESSAGE);
			}
			else if(user.getBatteries().size() >= 0 && user.getBatteries().size() <= 3 && user.getEngine().size() >= 0 && user.getEngine().size() <= 3) {
				engines = new ArrayList<Engine>();
				batteries = new ArrayList<Battery>();
				
				while(readBat.hasNextLine()) {
					exists = false;
					String line = new String(readBat.nextLine());
					Battery tmp = new Battery(line);
					
					for(i = 0; i != user.getBatteries().size(); i++) {
						if(user.getBatteries().get(i).equals(tmp)) {
							exists = true;
						}
					}
					if(!exists)
						batteries.add(new Battery(tmp));
				}
				while(readEn.hasNextLine()) {
					exists = false;
					String line = new String(readEn.nextLine());
					Engine tmp = new Engine(line);
					
					for(i = 0; i != user.getEngine().size(); i++) {
						if(user.getEngine().get(i).equals(tmp)) {
							exists = true;
						}
					}
					if(!exists)
						engines.add(new Engine(tmp));
				}
				readEn.close();
				readBat.close();
			}
		}catch(Exception e) {
			System.out.println("Error");
		}
		
		// BOUTONS DES ENGINES
		if(engines.size() > 0) {
			for(i = 0; i != engines.size() && i <= 3; i++) {
				String cover = new String("Moteur" + " (" + String.valueOf(engines.get(i).getPrice()) + ")");
				final Engine tmp = new Engine(engines.get(i));
				final TextButton button = new TextButton(cover, mySkin, "small");
				button.addListener(new MyInputListener(user, tmp) {
					
					@Override
		            public void touchUp (InputEvent event, float x, float y, int pointer, int utton) {
						String t = new String(button.getText().toString());
						if(user.getMoney() >= Integer.valueOf(t.substring(t.indexOf("(") + 1, t.indexOf(")")))) {
							user.addMoney((-Integer.valueOf(t.substring(t.indexOf("(") + 1, t.indexOf(")")))));
							user.addEngine(tmp);
							user.save();
							if(user.getBatteries().size() == 3 && user.getEngine().size() == 3)
								sm.set(new EmptyShopMenu(sm, user, cargame, restart, pscr));
							else
								sm.set(new ShopState(sm, user, cargame, restart, pscr));
						}
						else {
							JOptionPane.showMessageDialog(null, "Vous n'avez pas assez d'argent", "Pauvre", input.INFORMATION_MESSAGE);
						}
		            }
		            @Override
		            public boolean touchDown (InputEvent event, float x, float y, int pointer, int utton) {
		                return true;
		            }
				}
				);
				buttons.add(button);
				labels.add(new Label("Accel. : +" + tmp.getPower(), mySkin));
			}
			for(space = 30, i = 0,eW = engines.get(0).getLogo().getWidth(), eH = engines.get(0).getLogo().getHeight(),gW = Gdx.graphics.getWidth(), gH = Gdx.graphics.getHeight(); i != engines.size() && i <= 3; i++, space+=150) {
				
				engines.get(i).getLogo().setSize(60, 40);
				labels.get(i).setSize(engines.get(i).getLogo().getWidth(), engines.get(i).getLogo().getWidth()/6);

				engines.get(i).getLogo().setPosition(space + 10, gH - eH -20);
				labels.get(i).setPosition(space + 20, gH - eH - labels.get(i).getHeight() - 30);
				labels.get(i).setAlignment(Align.center);
				buttons.get(i).setPosition(space - 20, gH - eH - labels.get(i).getHeight() - buttons.get(i).getHeight() - 40);
				
				stage.addActor(engines.get(i).getLogo());
				stage.addActor(labels.get(i));
				stage.addActor(buttons.get(i));
			}
			
		}
		
		
		// BOUTONS DES BATTERIES
		if(batteries.size() > 0) {
			for(i = 0; i != batteries.size() && i <= 3; i++) {
				String cover = new String("Batterie " + " (" + String.valueOf(batteries.get(i).getPrice()) + ")");
				final Battery tmp = new Battery(batteries.get(i));
				final TextButton button = new TextButton(cover, mySkin, "small");
				button.addListener(new MyInputListener(this.user, tmp) {
					@Override
		            public void touchUp (InputEvent event, float x, float y, int pointer, int utton) {
						String t = new String(button.getText().toString());
						if(user.getMoney() >= Integer.valueOf(t.substring(t.indexOf("(") + 1, t.indexOf(")")))) {
							user.addMoney((-Integer.valueOf(t.substring(t.indexOf("(") + 1, t.indexOf(")")))));
							user.addBattery(tmp);
							user.save();
							if(user.getBatteries().size() == 3 && user.getEngine().size() == 3)
								sm.set(new EmptyShopMenu(sm, user, cargame, restart, pscr));
							else
								sm.set(new ShopState(sm, user, cargame, restart, pscr));
						}
						else {
							JOptionPane.showMessageDialog(null, "Vous n'avez pas assez d'argent", "Pauvre", input.INFORMATION_MESSAGE);
						}
					};
		            @Override
		            public boolean touchDown (InputEvent event, float x, float y, int pointer, int utton) {
		                return true;
		            }
				}
				);
				buttons.add(button);
				labels.add(new Label("Battery: " + tmp.getBatteryLeft() , mySkin));
			}
			for(space = 30, i = 0, j = engines.size(), gW = batteries.get(0).getLogo().getWidth(), bH = batteries.get(0).getLogo().getHeight(), gW = Gdx.graphics.getWidth(),gH = Gdx.graphics.getHeight()-150; i != batteries.size() && i <= 3; i+=1, j+=1, space+=150) {
				
				batteries.get(i).getLogo().setSize(40, 60);
				labels.get(j).setSize(batteries.get(i).getLogo().getWidth(), batteries.get(i).getLogo().getWidth()/6);
				
				batteries.get(i).getLogo().setPosition(space + 20, gH - bH - 50);
				labels.get(j).setPosition(space + 20, gH - bH - labels.get(j).getHeight() - 50);
				labels.get(j).setAlignment(Align.center);
				buttons.get(j).setPosition(space - 20, gH - bH - labels.get(j).getHeight() - buttons.get(j).getHeight() - 10 - 50);
				
				stage.addActor(batteries.get(i).getLogo());
				stage.addActor(labels.get(j));
				stage.addActor(buttons.get(j));
			}
		}	
	}

	@Override
	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();
	}
}
