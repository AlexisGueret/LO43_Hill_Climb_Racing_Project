package com.mygdx.game.States;

import java.util.Stack;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class StateManager{
	
	private Stack<State> states;

    public StateManager(){
    	this.states = new Stack<State>();
    }

    public void push(State state){
        states.push(state);
    }

    public void pop(){
        states.pop();
    }

    public void set(State state){
        states.pop();
    	states.push(state);
    }

    public void update(float dt) {}

    public void render(Stage stage){
        states.peek().render();
    }
}
