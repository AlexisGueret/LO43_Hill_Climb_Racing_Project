package com.mygdx.game.States;

import com.mygdx.game.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.InputEvent;

public class UserState extends State{

	public static final int WIDTH = 600;
	public static final int HEIGHT = 480;
	private int space = 50;
	private User user;
	private TextButton create, load, back;
	private Stage stage;
	private Skin skin;
	private Label userlabel;
	
	public UserState(final StateManager sm, User u, final CarGame cargame, final boolean restart, final PlayScreen pscr) {
		super(sm);
		
		stage = new Stage(new ScreenViewport());
		skin = new Skin(Gdx.files.internal("glassy/glassy-ui.json"));
		Gdx.input.setInputProcessor(stage);
		create = new TextButton("Creer compte", skin, "small");
		load = new TextButton("Charger compte", skin, "small");
		back = new TextButton("Retour", skin, "small");
		this.user = u;
		userlabel = new Label(user.getUsername() + "\n" + String.valueOf(user.getMoney()) + " pO", skin);
		userlabel.setPosition(WIDTH - userlabel.getWidth(), HEIGHT - userlabel.getHeight());
		stage.addActor(userlabel);
		
		create.setPosition(WIDTH/2 - create.getWidth() - space , HEIGHT/2 - create.getHeight()/2);
		load.setPosition(WIDTH/2 + load.getWidth()/2 - space, HEIGHT/2 - load.getHeight()/2);
		back.setPosition(WIDTH/2 - back.getWidth()/2, back.getHeight());
		
		create.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				TextZone createZone = new TextZone();
				user = new User(createZone.createUser());
				sm.set(new UserState(sm, user, cargame, restart, pscr));

            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		load.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				TextZone createZone = new TextZone();
				user = new User(createZone.loadUser());
				sm.set(new UserState(sm, user, cargame, restart, pscr));

            }
			
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		back.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new MainMenu(sm, user, cargame, restart, pscr));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		});
		
		stage.addActor(load);
		stage.addActor(create);
		stage.addActor(back);
	}

	@Override
	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();
	}
}
