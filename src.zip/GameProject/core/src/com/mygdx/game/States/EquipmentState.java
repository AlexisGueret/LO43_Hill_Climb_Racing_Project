package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.Align;
import com.mygdx.game.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class EquipmentState extends State {
	
	public static final int WIDTH = 600;
	public static final int HEIGHT = 480;
	private Stage stage;
	private Skin mySkin;
	private ArrayList<TextButton> buttonsE;
	private ArrayList<TextButton> buttonsB;
	private TextButton backToMenu;
	private ArrayList<Label> labelsE;
	private ArrayList<Label> labelsB;
	private Label userlabel;
	private User user;

	public EquipmentState(final StateManager sm, User u, final CarGame cargame, final boolean restart, final PlayScreen pscr) {
		super(sm);
		
		// INITIALISATION
		int i, j;
		float gW, gH, eH, bH, eW, bW, space;
		stage = new Stage(new ScreenViewport());
		mySkin = new Skin(Gdx.files.internal("glassy/glassy-ui.json"));
		this.user = u;
		Gdx.input.setInputProcessor(stage);
		userlabel = new Label(user.getUsername() + "\n" + String.valueOf(user.getMoney()) + " pO", mySkin);
		userlabel.setPosition(WIDTH - userlabel.getWidth(), HEIGHT - userlabel.getHeight());
		stage.addActor(userlabel);
		

        // Création
		this.backToMenu = new TextButton("Retour", mySkin, "small");
		
		this.backToMenu.setPosition(WIDTH - backToMenu.getWidth() , backToMenu.getHeight());
		backToMenu.addListener(new MyInputListener(this.user) {
			@Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
				sm.set(new MainMenu(sm, user, cargame, restart, pscr));
				
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
		}
		);
		stage.addActor(backToMenu);
		
		buttonsE = new ArrayList<TextButton>();
		buttonsB = new ArrayList<TextButton>();
		labelsE = new ArrayList<Label>();
		labelsB = new ArrayList<Label>();
		
		System.out.println(user.getBatteries().size() + " " + user.getEngine().size());
		if(user.getBatteries().size() == 0 && user.getEngine().size() == 0) {
			sm.set(new EmptyShopMenu(sm, user, cargame, restart, pscr));
		}
		
		// BOUTONS DES ENGINES
		if(user.getEngine().size() > 0) {
			for(i = 0; i != user.getEngine().size() ; i++) {
				String cover = new String("Equiper " + user.getEngine().get(i).getName());
				final Engine tmp = new Engine(user.getEngine().get(i));
				final int it = i;
				final TextButton button = new TextButton(cover, mySkin, "small");
				button.addListener(new MyInputListener(user, tmp, it) {
					@Override
		            public void touchUp (InputEvent event, float x, float y, int pointer, int utton) {
						if(user.getEngine().size() == 1) {
							button.setDisabled(true);
						}
						else{
							user.getEngine().set(it, user.getEngine().get(0));
							user.getEngine().set(0, tmp);
						}
						JOptionPane.showMessageDialog(null, "Vous avez equipe le moteur " + tmp.getName(), "Penurie", JOptionPane.INFORMATION_MESSAGE);
						user.save();
						sm.set(new EquipmentState(sm, user, cargame, restart, pscr));
		            }
		            @Override
		            public boolean touchDown (InputEvent event, float x, float y, int pointer, int utton) {
		                return true;
		            }
				}
				);
				buttonsE.add(button);
				labelsE.add(new Label("Accel. : +" + tmp.getPower(), mySkin));
			}
			for(space = 30, i = 0,eW = user.getEngine().get(0).getLogo().getWidth(), eH = user.getEngine().get(0).getLogo().getHeight(),gW = Gdx.graphics.getWidth(), gH = Gdx.graphics.getHeight(); i != user.getEngine().size(); i++, space+=150) {
				
				user.getEngine().get(i).getLogo().setSize(60, 40);
				labelsE.get(i).setSize(user.getEngine().get(i).getLogo().getWidth(), user.getEngine().get(i).getLogo().getWidth()/6);

				user.getEngine().get(i).getLogo().setPosition(space + 50, gH - eH -20);
				labelsE.get(i).setPosition(space + 30, gH - eH - labelsE.get(i).getHeight() - 30);
				labelsE.get(i).setAlignment(Align.center);
				buttonsE.get(i).setPosition(space - 50, gH - eH - labelsE.get(i).getHeight() - buttonsE.get(i).getHeight() - 40);
				
				stage.addActor(user.getEngine().get(i).getLogo());
				stage.addActor(labelsE.get(i));
				stage.addActor(buttonsE.get(i));
			}
			
		}
		
		// BOUTONS DES BATTERIES
		if(user.getBatteries().size() > 0) {
			for(i = 0; i != user.getBatteries().size(); i++) {
				String cover = new String("Equiper " + user.getBatteries().get(i).getName());
				final Battery tmp = new Battery(user.getBatteries().get(i));
				final int it = i;
				final TextButton button = new TextButton(cover, mySkin, "small");
				button.addListener(new MyInputListener(user, tmp, it) {
					@Override
		            public void touchUp (InputEvent event, float x, float y, int pointer, int utton) {
						if(user.getBatteries().size() == 1) {
							button.setDisabled(true);
						}
						else{
							user.getBatteries().set(it, user.getBatteries().get(0));
							user.getBatteries().set(0, tmp);
						}
						JOptionPane.showMessageDialog(null, "Vous avez equipe la batterie " + tmp.getName(), "Penurie", JOptionPane.INFORMATION_MESSAGE);
						user.save();
						sm.set(new EquipmentState(sm, user, cargame, restart, pscr));
		            }
		            @Override
		            public boolean touchDown (InputEvent event, float x, float y, int pointer, int utton) {
		                return true;
		            }
				}
				);
				buttonsB.add(button);
				labelsB.add(new Label("Battery: " + tmp.getBatteryLeft() , mySkin));
			}
			System.out.println("test");
			for(space = 30, i = 0, gW = user.getBatteries().get(0).getLogo().getWidth(), bH = user.getBatteries().get(0).getLogo().getHeight(), gW = Gdx.graphics.getWidth(),gH = Gdx.graphics.getHeight()-150; i != user.getBatteries().size(); i+=1, space+=150) {
				
				user.getBatteries().get(i).getLogo().setSize(40, 60);
				labelsB.get(i).setSize(user.getBatteries().get(i).getLogo().getWidth(), user.getBatteries().get(i).getLogo().getWidth()/6);
				
				user.getBatteries().get(i).getLogo().setPosition(space + 20, gH - bH - 50);
				labelsB.get(i).setPosition(space + 10, gH - bH - labelsB.get(i).getHeight() - 50);
				labelsB.get(i).setAlignment(Align.center);
				buttonsB.get(i).setPosition(space - 20, gH - bH - labelsB.get(i).getHeight() - buttonsB.get(i).getHeight() - 10 - 50);
				
				stage.addActor(user.getBatteries().get(i).getLogo());
				stage.addActor(labelsB.get(i));
				stage.addActor(buttonsB.get(i));
			}
		}
	}
	
	@Override
	public void render() {
		Gdx.gl.glClearColor(0,0,0,0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();
	}
	
}
