package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.joints.WheelJoint;
import com.badlogic.gdx.physics.box2d.joints.WheelJointDef;

public class Truck extends Vehicle {

	
	public Truck(World world,float e,PlayScreen p) {
		super(world,e,p);
		this.battery=new Battery("aaaa;100;122");
		
		this.img=new Texture(
				Gdx.files.internal(
						"bus01.png"
				)
				);
		
		animation=new TextureRegion[4];
		animation[0]=new TextureRegion(new Texture(Gdx.files.internal("bus01.png").file().getAbsolutePath()));
		animation[1]=new TextureRegion(new Texture(Gdx.files.internal("bus02.png").file().getAbsolutePath()));
		animation[2]=new TextureRegion(new Texture(Gdx.files.internal("bus03.png").file().getAbsolutePath()));
		animation[3]=new TextureRegion(new Texture(Gdx.files.internal("bus04.png").file().getAbsolutePath()));
		
		
				
		defineVehicle();
		
	}
	
	
	@Override
	public void defineVehicle()
	{
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = BodyType.DynamicBody;
		bodyDef.position.set(ps.getGame().getMaps().get(ps.getMapNumber()).getxBegin(), ps.getGame().getMaps().get(ps.getMapNumber()).getyBegin());
		
		height=0.15f;
		width=0.5f;
		
		
		// cr�ation du chassis
		PolygonShape chassisShape = new PolygonShape();
		chassisShape.set(new float[] {(-width/2 ) , (-height/2 ), ( width / 2), (-height/2), (width / 2 * .4f), (height / 2), (-width / 2 * .8f), (height / 2 * .8f)});
		chassisFixtureDef=new FixtureDef();
		chassisFixtureDef.shape = chassisShape;
		chassisFixtureDef.density=3f;
		chassisFixtureDef.friction=0.4f;
		chassisFixtureDef.restitution=0.3f;
		chassis = world.createBody(bodyDef);
		chassis.createFixture(chassisFixtureDef);

		// left wheel
		CircleShape wheelShape = new CircleShape();
		wheelShape.setRadius((height / 2.5f) );
		 FixtureDef wheelFixtureDef=new FixtureDef();

		wheelFixtureDef.shape = wheelShape;
		wheelFixtureDef.density = chassisFixtureDef.density*2.5f;
		wheelFixtureDef.friction=6;
		wheelFixtureDef.restitution=0.4f;
		leftWheel = world.createBody(bodyDef);
		leftWheel.createFixture(wheelFixtureDef);

		// right wheel
		rightWheel = world.createBody(bodyDef);
		rightWheel.createFixture(wheelFixtureDef);

		// left axis( ce qui relie la roue gauche et le chassis)
		WheelJointDef axisDef = new WheelJointDef();
		axisDef.bodyA = chassis;
		axisDef.bodyB = leftWheel;
		axisDef.localAnchorA.set(-width / 2  + wheelShape.getRadius(), -height / 2 * 1.25f);
		axisDef.frequencyHz = chassisFixtureDef.density;
		
		axisDef.localAxisA.set(Vector2.Y);
		axisDef.maxMotorTorque = //chassisFixtureDef.density * 10
				motorTorque;
		leftAxis = (WheelJoint) world.createJoint(axisDef);

		// right axis ( ce qui relie la roue droite et le chassis)
		axisDef.bodyB = rightWheel;
		axisDef.localAnchorA.x *= -0.75;

		rightAxis = (WheelJoint) world.createJoint(axisDef);
		
		rightWheel.setUserData("car");
		leftWheel.setUserData("car");
		chassis.setUserData("car");
	}
	
	
	
	
	

}
