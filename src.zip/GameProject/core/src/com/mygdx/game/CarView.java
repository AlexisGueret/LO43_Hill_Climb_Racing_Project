package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;


public class CarView extends Sprite {
	float stateTime=0;
	int currentState;
	Vehicle vehicle;
	PlayScreen ps;
	Texture text;
	float x,y;
	TextureRegion textr;
	TextureRegion[] rollingAnim;
	Animation<TextureRegion> animation;
	int i=2;
	private float rotation=0;
	
	public CarView(Vehicle car,PlayScreen screen)
	{
		
		super();
		
		this.vehicle=car;
		this.ps=screen;
		Sprite s=new Sprite(car.getImg());
		TextureRegion text=new TextureRegion(car.getImg());
		s.setSize(s.getWidth()/CarGame.PPM, s.getHeight()/CarGame.PPM);
		
		this.setRegion(text);
		if(car instanceof Car)
		{
			this.setBounds(0, 0, 32/CarGame.PPM, 16/CarGame.PPM);
		}
		if (car instanceof Truck )
		{
			this.setBounds(0, 0, 52/CarGame.PPM, 24/CarGame.PPM);
		}

		this.setOrigin(this.getWidth()/2, this.getHeight()/2);

	}
	public void update(float dt)
	{
		
		DrawAnimation();
		this.setPosition(
				vehicle.getBody().getPosition().x 
				
				-(vehicle.width)/2
				,vehicle.getBody().getPosition().y
				
				-(vehicle.height)
				
				);

		this.setRotation((float)Math.toDegrees(vehicle.getBody().getAngle()));	
	}
	
	
	public void draw(SpriteBatch batch)
	{
		super.draw(batch);
		
	}
	
	
	public void DrawAnimation()
	{
		
		
		
		if(vehicle instanceof Car || vehicle instanceof Truck)
		{
			
		
			if(vehicle.getBody().getLinearVelocity().x>0.1f)
					
			{
			
				if(i==10)
				{
					setRegion(vehicle.getArrayAnimation()[0]);
					i++;
			
				}
				else
				{
					i++;
				}
				if(i==20)
				{
					setRegion(vehicle.getArrayAnimation()[1]);
			
				}
				if(i==30)
				{
					setRegion(vehicle.getArrayAnimation()[2]);
				}
				if(i==40)
					{
					setRegion(vehicle.getArrayAnimation()[3]);
					}
				if(i==51)
				{
					i=0;
				}
			}
			else
			{
				if(vehicle.getBody().getLinearVelocity().x<-0.1f)
				{
					if(i==10)
					{
						setRegion(vehicle.getArrayAnimation()[0]);
						i--;
				
					}
					else
					{
						i--;
					}
					if(i==20)
					{
						setRegion(vehicle.getArrayAnimation()[1]);
				
					}
					if(i==30)
					{
						setRegion(vehicle.getArrayAnimation()[2]);
					}
					if(i==40)
					{
						setRegion(vehicle.getArrayAnimation()[3]);
					}
					if(i==0)
					{
						i=50;
					}
			}
		}
	}
	}
	
	
}
