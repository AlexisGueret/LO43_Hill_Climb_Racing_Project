package com.mygdx.game;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.badlogic.gdx.Gdx;


public class TextZone extends JFrame {

	private String text;
	private Scanner read;
	private JOptionPane input;
	private User user;
	private String final_line;
	private boolean good;
	
	public TextZone() {
		good = false;
	}
	
	public User createUser(){	
		try {
			int test = 1;
			while(test != 0) {
				test = 0;
				text = new String(input.showInputDialog("Entrez votre nom d'utilisateur : "));	
				//File testp = new File("TEST.txt");
				//String path = new String(testp.getAbsolutePath().toString().substring(0, testp.getAbsolutePath().toString().indexOf("desk")) + "core/assets/");    
				//read = new Scanner(new FileInputStream(path + "users.txt"));
				read = new Scanner(Gdx.files.internal("users.txt").read());
				
				int lineNum = 0;
			    while (read.hasNextLine()) {
					String line = read.nextLine();
					lineNum++;
					
					if(line.indexOf(text)!=-1) {
						if(line.substring(line.indexOf(text), line.indexOf(";")).equals(text)) {
							test = 1;
							input.showMessageDialog(null, "Nom deja utilise, veuillez recommencer", "Information", input.INFORMATION_MESSAGE);
						}
					}
			    }
			}			
				
		}catch(Exception e) {
			input.showMessageDialog(null, "Erreur lors de l'execution du programme, veuillez recommencer", "Information", input.INFORMATION_MESSAGE);
		}
		read.close();
		User tmp = new User(text, 0);
		tmp.save();
		return tmp;
	}
	
	public User loadUser(){	
		try {
			int test = 1;
			while(good == false) {
				text = new String(input.showInputDialog("Entrez votre nom d'utilisateur : "));	
				//File testp = new File("TEST.txt");
				//String path = new String(testp.getAbsolutePath().toString().substring(0, testp.getAbsolutePath().toString().indexOf("desk")) + "core/assets/");
				read = new Scanner(Gdx.files.internal("users.txt").read());

				int lineNum = 0;
			    while (read.hasNextLine()) {
					String line = new String(read.nextLine());
					if(text.equals("")) {
						input.showMessageDialog(null, "Impossible de charger le profil, fermeture du programme", "Information", input.INFORMATION_MESSAGE);
						good = false;
					}
					if(line.indexOf(text)!= -1) {
						if(line.substring(line.indexOf(text), line.indexOf(";")).equals(text)) {
						input.showMessageDialog(null, "Votre profil est charge", "Information", input.INFORMATION_MESSAGE);
						this.final_line = new String(line);
						good = true;
						}
					}
			    }
				read.close();
				if(good == false) {
					input.showMessageDialog(null, "Votre profil est introuvable, il est soit inexistant soit incorrect, veuillez reessayer", "Information", input.INFORMATION_MESSAGE);
				}
				
			}			
				
		}catch(Exception e) {
			input.showMessageDialog(null, "Erreur lors de l'execution du programme, veuillez recommencer", "Information", input.INFORMATION_MESSAGE);
		}
		return new User(final_line);
	}	
	
}

