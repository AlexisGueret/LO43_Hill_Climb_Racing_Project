package com.mygdx.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygdx.game.CarGame;


public class DesktopLauncher {
	private static final String TITLE="OMG MON SUPER JEU";
	private static final int WIDTH = 700;
	private static final int HEIGHT = 400;
	
	
	
	
	
	
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		
		config.title=TITLE;
		config.width=WIDTH;
		config.height=HEIGHT;
		new LwjglApplication(new CarGame(), config);
	}
}
