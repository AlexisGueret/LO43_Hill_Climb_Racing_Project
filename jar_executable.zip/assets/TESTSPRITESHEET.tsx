<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="TESTSPRITESHEET" tilewidth="16" tileheight="16" tilecount="9" columns="1">
 <image source="../../../TESTSPRITESHEET.png" width="16" height="152"/>
</tileset>
