<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="prev_28(1)" tilewidth="40" tileheight="40" spacing="35" margin="1" tilecount="80" columns="10">
 <image source="../../../../Downloads/2D Platformer Snow Pack _ OpenGameArt.org_files/prev_28(1).png" width="725" height="567"/>
</tileset>
